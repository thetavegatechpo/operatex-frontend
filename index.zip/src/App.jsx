import React, { useContext } from "react";

import {
    BrowserRouter,
    Routes,
    Route,
    Navigate
} from "react-router-dom";

import { AuthContext } from "./context/AuthContext";

import Login from "./pages/login/login";

import Layout from "./components/layout/Layout";

import Dashboard from "./pages/Dashboard/Dashboard";


/* =====================================
   ENTERPRISE SETUP
===================================== */

import CompanyMaster from "./pages/CompanyMaster/CompanyMaster";
import PlantShopMaster from "./pages/PlantShopMaster/PlantShopMaster";
import LineMaster from "./pages/LineMaster/LineMaster";
import ShiftCalendar from "./pages/ShiftCalendar/ShiftCalendar";
import ModuleEnablement from "./pages/ModuleEnablement/ModuleEnablement";
import UserRolePermission from "./pages/UserRolePermission/UserRolePermission";
import StationMaster from "./pages/station-master/StationMaster";


/* =====================================
   MASTER DATA
===================================== */

import MachineMaster from "./pages/MachineMaster/MachineMaster";
import DeviceMaster from "./pages/DeviceMaster/DeviceMaster";
import SignalMapping from "./pages/SignalMapping/SignalMapping";
import PartMaster from "./pages/PartMaster/PartMaster";
import ProcessMaster from "./pages/ProcessMaster/ProcessMaster";
import RouteMaster from "./pages/RouteMaster/RouteMaster";
import ToolMaster from "./pages/ToolMaster/ToolMaster";
import GaugeInstrumentMaster from "./pages/GaugeInstrumentMaster/GaugeInstrumentMaster";
import DocumentMaster from "./pages/DocumentMaster/DocumentMaster";
import SkillMatrix from "./pages/SkillMatrix/SkillMatrix";


/* =====================================
   PLANNING
===================================== */

import ProductionOrder from "./pages/ProductionOrder/ProductionOrder";

import Productionplan from "./pages/ProductionPlan/ProductionPlan";

import ShiftPlan from "./pages/ShiftPlan/ShiftPlan";
import SchedulingRules from "./pages/SchedulingRules/SchedulingRules";
import MaterialBatchHeatCode
  from "./pages/MaterialBatchHeatCode/MaterialBatchHeatCode";
  import ChangeoverSetupPlan
    from "./pages/ChangeoverSetupPlan/ChangeoverSetupPlan";
import OperatorWorkstation
  from "./pages/OperatorWorkstation/OperatorWorkstation";

import ProductionCount
    from "./pages/ProductionCount/ProductionCount";

import CycleTimeTracking
    from "./pages/CycleTimeTracking/CycleTimeTracking"; 
    
import MachineStatus from "./pages/MachineStatus/MachineStatus"; 

import LineIndexingUnitMovement from "./pages/LineIndexingUnitMovement/LineIndexingUnitMovement";

import ReworkRejectBypass
  from "./pages/ReworkRejectBypass/ReworkRejectBypass";

  import DowntimeDetection
    from "./pages/DowntimeDetection/DowntimeDetectionPage";
import Availability from "./pages/Availability/Availability";
import Performance from "./pages/Performance/Performance";
import Quality from "./pages/Quality/Quality";
import OEE from "./pages/OEE/OEE";
import BreakdownManagement from "./pages/BreakdownManagement/BreakdownManagement";
import MttrMtbf from "./pages/MttrMtbf/MttrMtbf";
import LossTree from './pages/LossTree/LossTree';
/* =====================================
   PROTECTED ROUTE
===================================== */

function ProtectedRoute({ children }) {

    const { isAuthenticated } =
        useContext(AuthContext);

    return isAuthenticated
        ? children
        : (
            <Navigate
                to="/login"
                replace
            />
        );
}


/* =====================================
   APP
===================================== */

function App() {

    return (

        <BrowserRouter>

            <Routes>

                {/* =====================================
                    LOGIN
                ====================================== */}

                <Route
                    path="/login"
                    element={<Login />}
                />


                {/* =====================================
                    MAIN LAYOUT
                ====================================== */}

                <Route
                    path="/"
                    element={
                        <ProtectedRoute>
                            <Layout />
                        </ProtectedRoute>
                    }
                >

                    {/* DEFAULT */}

                    <Route
                        index
                        element={
                            <Navigate
                                to="/dashboard"
                                replace
                            />
                        }
                    />


                    {/* =====================================
                        DASHBOARD
                    ====================================== */}

                    <Route
                        path="dashboard"
                        element={<Dashboard />}
                    />


                    {/* =====================================
                        ENTERPRISE SETUP
                    ====================================== */}

                    <Route
                        path="company-master"
                        element={<CompanyMaster />}
                    />

                    <Route
                        path="plant-shop-master"
                        element={<PlantShopMaster />}
                    />

                    <Route
                        path="line-master"
                        element={<LineMaster />}
                    />

                    <Route
                        path="shift-calendar"
                        element={<ShiftCalendar />}
                    />

                    <Route
                        path="user-role-permission"
                        element={<UserRolePermission />}
                    />

                    <Route
                        path="module-enablement"
                        element={<ModuleEnablement />}
                    />

                    <Route
                        path="station-master"
                        element={<StationMaster />}
                    />


                    {/* =====================================
                        MASTER DATA
                    ====================================== */}

                    <Route
                        path="machine-master"
                        element={<MachineMaster />}
                    />

                    <Route
                        path="device-master"
                        element={<DeviceMaster />}
                    />

                    <Route
                        path="signal-mapping"
                        element={<SignalMapping />}
                    />

                    <Route
                        path="part-master"
                        element={<PartMaster />}
                    />

                    <Route
                        path="process-master"
                        element={<ProcessMaster />}
                    />

                    <Route
                        path="route-master"
                        element={<RouteMaster />}
                    />

                    <Route
                        path="tool-master"
                        element={<ToolMaster />}
                    />

                    <Route
                        path="gauge-instrument-master"
                        element={<GaugeInstrumentMaster />}
                    />

                    <Route
                        path="document-master"
                        element={<DocumentMaster />}
                    />

                    <Route
                        path="skill-matrix"
                        element={<SkillMatrix />}
                    />


                    {/* =====================================
                        PLANNING
                    ====================================== */}

                    <Route
                        path="production-order"
                        element={<ProductionOrder />}
                    />


                      <Route
                        path="production-Plan"
                        element={<Productionplan />}
                    />
<Route
    path="/shift-plan"
    element={<ShiftPlan />}
/>

<Route
  path="/scheduling-rules"
  element={<SchedulingRules />}
/>
<Route
  path="/material-batch-heat-code"
  element={<MaterialBatchHeatCode />}
/>

<Route
    path="/changeover-setup-plan"
    element={<ChangeoverSetupPlan />}
/>


<Route
  path="/operator-workstation"
  element={<OperatorWorkstation />}
/>

<Route
    path="/production-count"
    element={<ProductionCount />}
/>

<Route
    path="/cycle-time-tracking"
    element={<CycleTimeTracking />}
/>

<Route
    path="/machine-status"
    element={<MachineStatus />}
/>

<Route
    path="/line-indexing-unit-movement"
    element={<LineIndexingUnitMovement />}

/>  <Route
  path="/rework-reject-bypass"
  element={<ReworkRejectBypass />}
/> 
<Route
    path="/downtime-detection"
    element={<DowntimeDetection />}
/>
<Route path="/availability" element={<Availability />} />

<Route
    path="performance"
    element={<Performance />}
/>

<Route path="/oee" element={<OEE />} />


<Route path="/quality" element={<Quality />} />

<Route path="/breakdown-management" element={<BreakdownManagement />} />  
<Route path="/mttr-mtbf" element={<MttrMtbf />}/>  
<Route path="/loss-tree" element={<LossTree />} />

                </Route> 

            


                {/* =====================================
                    404
                ====================================== */}

                <Route
                    path="*"
                    element={
                        <Navigate
                            to="/login"
                            replace
                        />
                    }
                />

            </Routes>

        </BrowserRouter>
    );
}

export default App;