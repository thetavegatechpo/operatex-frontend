// src/utils/auth.js

export const TOKEN_KEY = "operatex_token";

export const USER_KEY = "operatex_user";

export const saveToken = (token) => {

    localStorage.setItem(TOKEN_KEY, token);

};

export const getToken = () => {

    return localStorage.getItem(TOKEN_KEY);

};

export const removeToken = () => {

    localStorage.removeItem(TOKEN_KEY);

};

export const saveUser = (user) => {

    localStorage.setItem(

        USER_KEY,

        JSON.stringify(user)

    );

};

export const getUser = () => {

    const user = localStorage.getItem(USER_KEY);

    return user ? JSON.parse(user) : null;

};

export const removeUser = () => {

    localStorage.removeItem(USER_KEY);

};

export const logout = () => {

    removeToken();

    removeUser();

};