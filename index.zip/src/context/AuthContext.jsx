import React, {
    createContext,
    useState
} from "react";

import {

    getToken,

    getUser,

    saveToken,

    saveUser,

    logout

} from "../utils/auth";

export const AuthContext = createContext();

export function AuthProvider({ children }) {

    const [token, setToken] = useState(getToken());

    const [user, setUser] = useState(getUser());

    const login = (jwt, userData) => {

        saveToken(jwt);

        saveUser(userData);

        setToken(jwt);

        setUser(userData);

    };

    const signOut = () => {

        logout();

        setToken(null);

        setUser(null);

    };

    return (

        <AuthContext.Provider
            value={{

                token,

                user,

                login,

                signOut,

                isAuthenticated: !!token

            }}
        >

            {children}

        </AuthContext.Provider>

    );

}