import React from "react";
import ReactDOM from "react-dom/client";

/* Bootstrap base first */
import "bootstrap/dist/css/bootstrap.min.css";

/* Your original OperateX global CSS AFTER Bootstrap */
import "./index.css";
// import "./App.css";          // only if this existed before
// import "./styles/global.css"; // only if this existed before

import {
    QueryClient,
    QueryClientProvider
} from "@tanstack/react-query";

import {
    AuthProvider
} from "./context/AuthContext";

import App from "./App";


const queryClient =
    new QueryClient({
        defaultOptions: {
            queries: {
                refetchOnWindowFocus: false,
                retry: 1
            }
        }
    });


ReactDOM.createRoot(
    document.getElementById("root")
).render(
    <React.StrictMode>

        <QueryClientProvider
            client={queryClient}
        >

            <AuthProvider>
                <App />
            </AuthProvider>

        </QueryClientProvider>

    </React.StrictMode>
);