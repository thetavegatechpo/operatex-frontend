// src/components/layout/Sidebar.jsx

import React, { useState } from "react";

import {
    Accordion
} from "react-bootstrap";

import {
    HouseDoorFill,
    Building,
    Diagram3Fill,
    CpuFill,
    ClipboardDataFill,
    WrenchAdjustableCircleFill,
    FileTextFill,
    PersonCircle,
    List,
    CalendarCheckFill
} from "react-bootstrap-icons";

import {
    NavLink
} from "react-router-dom";

import "./Sidebar.css";


function Sidebar() {

    const [collapsed, setCollapsed] =
        useState(false);


    const user = JSON.parse(
        localStorage.getItem(
            "operatex_user"
        )
    );


    // =====================================================
    // ENTERPRISE SETUP
    // =====================================================

    const enterpriseMenu = [

        {
            title: "Company Master",
            path: "/company-master"
        },

        {
            title: "Plant / Shop Master",
            path: "/plant-shop-master"
        },

        {
            title: "Line Master",
            path: "/line-master"
        },

        {
            title: "Shift Calendar",
            path: "/shift-calendar"
        },

        {
            title: "User Role Permission",
            path: "/user-role-permission"
        },

        {
            title: "Module-Enablement",
            path: "/module-Enablement"
        }

    ];


    // =====================================================
    // MASTER DATA
    // =====================================================

    const masterMenu = [

        {
            title: "Machine Master",
            path: "/machine-master"
        },

        {
            title: "Device Master",
            path: "/device-master"
        },

        {
            title: "Signal Mapping",
            path: "/signal-mapping"
        },

        {
            title: "Part Master",
            path: "/part-master"
        },

        {
            title: "Process Master",
            path: "/process-master"
        },

        {
            title: "Route / Station Master",
            path: "/route-master"
        },

        {
            title: "Tool Master",
            path: "/tool-master"
        },

        {
            title: "Gauge / Instrument Master",
            path: "/gauge-instrument-master"
        },

        {
            title: "Document / SOP Master",
            path: "/document-master"
        },

        {
            title: "Skill-Matrix",
            path: "/skill-matrix"
        }

    ];


    // =====================================================
    // PLANNING
    // =====================================================

    const planningMenu = [

        {
            title: "Production Order",
            path: "/production-order"
        },

        {
            title: "Production Plan",
            path: "/production-plan"
        },

        {
            title: "Shift Plan",
            path: "/shift-plan"
        },

        {
            title: "Scheduling Rules",
            path: "/scheduling-rules"
        },

        {
            title: "Material / Batch / Heat Code",
            path: "/material-batch-heat-code"
        },

        {
            title: "Changeover / Setup Plan",
            path: "/changeover-setup-plan"
        }

    ];


    // =====================================================
    // PRODUCTION EXECUTION
    // =====================================================
    //
    // Production Execution contains six canonical submodules.
    //
    // Operator Workstation is implemented now.
    //
    // Remaining modules are shown in the sidebar but kept
    // disabled until their frontend page + route are created.
    //
    // =====================================================

    const productionExecutionMenu = [

        {
            title: "Operator Workstation",
            path: "/operator-workstation",
            disabled: false
        },

        {
            title: "Production Count",
            path: "/production-count",
            disabled: false
        },

        {
            title: "Cycle Time Tracking",
            path: "/cycle-time-tracking",
            disabled: false

        },

        {
            title: "Machine Status",
            path: "/machine-status",
            disabled: false
        },

        {
            title: "Line Indexing / Unit Movement",
            path: "/line-indexing-unit-movement",
            disabled: false
        },

        {
            title: "Rework / Reject / Bypass",
            path: "/rework-reject-bypass",
            disabled: false
        }

    ];

    // =====================================================
// OEE & LOSS
// =====================================================

const oeeLossMenu = [

    {
        title:
            "Downtime Detection",

        path:
            "/downtime-detection",

        disabled:false
    },

     {
        title:
            "Availability",

        path:
            "/availability",

        disabled:false
    },

     {
        title:
            "Performance",

        path:
            "/performance",

        disabled:false
    },
    {
        title:
            "Quality",

        path:
            "/quality",

        disabled:false
    },
    {
        title:
            "OEE",

        path:
            "/oee",

        disabled:false
    },
       {
        title:
            "Breakdown Management",

        path:
            "/breakdown-management",

        disabled:false
    },

    {
        title:
            "MTTR / MTBF",

        path:
            "/mttr-mtbf",

        disabled:false
    },

    {
        title:
            "Loss Tree",

        path:
            "/loss-tree",

        disabled:false
    },

];


    // =====================================================
    // SUBMENU RENDER HELPER
    // =====================================================

    const renderMenuItems = (menu) => {

        return menu.map(
            item => {

                // =============================================
                // DISABLED / UPCOMING MODULE
                // =============================================

                if (item.disabled) {

                    return (

                        <div
                            key={item.path}
                            className="submenu-link"
                            style={{
                                opacity: 0.45,
                                cursor: "not-allowed",
                                userSelect: "none"
                            }}
                            title="Module will be enabled after implementation"
                        >

                            <span className="submenu-line"></span>

                            {item.title}

                        </div>

                    );
                }


                // =============================================
                // ACTIVE MENU
                // =============================================

                return (

                    <NavLink
                        key={item.path}
                        to={item.path}
                        className="submenu-link"
                    >

                        <span className="submenu-line"></span>

                        {item.title}

                    </NavLink>

                );
            }
        );
    };


    return (

        <div
            className={
                collapsed
                    ? "sidebar collapsed"
                    : "sidebar"
            }
        >

            {/* ===========================
                USER
            ============================ */}

            <div className="user-panel">

                <PersonCircle
                    size={42}
                />

                {
                    !collapsed &&

                    <div>

                        <div className="user-name">

                            {user?.username}

                        </div>

                        <small>

                            {user?.role_name}

                        </small>

                    </div>
                }


                <button
                    className="collapse-btn"
                    onClick={() =>
                        setCollapsed(
                            !collapsed
                        )
                    }
                >

                    <List size={22} />

                </button>

            </div>


            {/* ===========================
                DASHBOARD
            ============================ */}

            <NavLink
                to="/dashboard"
                className="menu-link"
            >

                <HouseDoorFill />

                {
                    !collapsed &&

                    <span>
                        Dashboard
                    </span>
                }

            </NavLink>


            {/* ===========================
                ACCORDION
            ============================ */}

            <Accordion
                alwaysOpen
                className="sidebar-menu"
            >


                {/* ======================================
                    ENTERPRISE SETUP
                ======================================= */}

                <Accordion.Item eventKey="0">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <Building />

                            {
                                !collapsed &&

                                <span>
                                    Enterprise Setup
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        {
                            renderMenuItems(
                                enterpriseMenu
                            )
                        }

                    </Accordion.Body>

                </Accordion.Item>


                {/* ======================================
                    MASTER DATA
                ======================================= */}

                <Accordion.Item eventKey="1">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <Diagram3Fill />

                            {
                                !collapsed &&

                                <span>
                                    Master Data
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        {
                            renderMenuItems(
                                masterMenu
                            )
                        }

                    </Accordion.Body>

                </Accordion.Item>


                {/* ======================================
                    PLANNING
                ======================================= */}

                <Accordion.Item eventKey="2">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <CalendarCheckFill />

                            {
                                !collapsed &&

                                <span>
                                    Planning
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        {
                            renderMenuItems(
                                planningMenu
                            )
                        }

                    </Accordion.Body>

                </Accordion.Item>


                {/* ======================================
                    PRODUCTION EXECUTION
                ======================================= */}

                <Accordion.Item eventKey="3">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <CpuFill />

                            {
                                !collapsed &&

                                <span>
                                    Production Execution
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        {
                            renderMenuItems(
                                productionExecutionMenu
                            )
                        }

                    </Accordion.Body>

                </Accordion.Item>
                {/* ======================================
    OEE & LOSS
======================================= */}

<Accordion.Item eventKey="4">


<Accordion.Header>


<div className="accordion-title">

<CpuFill />


{
!collapsed &&

<span>
OEE & Loss
</span>

}


</div>


</Accordion.Header>



<Accordion.Body>


{
renderMenuItems(
    oeeLossMenu
)
}


</Accordion.Body>


</Accordion.Item>


                {/* ======================================
                    QUALITY
                ======================================= */}

                <Accordion.Item eventKey="4">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <ClipboardDataFill />

                            {
                                !collapsed &&

                                <span>
                                    Quality
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        <NavLink
                            to="/inspection"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Inspection

                        </NavLink>


                        <NavLink
                            to="/quality-dashboard"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Quality Dashboard

                        </NavLink>

                    </Accordion.Body>

                </Accordion.Item>


                {/* ======================================
                    MAINTENANCE
                ======================================= 

                <Accordion.Item eventKey="5">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <WrenchAdjustableCircleFill />

                            {
                                !collapsed &&

                                <span>
                                    Maintenance
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        <NavLink
                            to="/preventive-maintenance"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Preventive Maintenance

                        </NavLink>


                        <NavLink
                            to="/breakdown"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Breakdown

                        </NavLink>


                        <NavLink
                            to="/maintenance-dashboard"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Maintenance Dashboard

                        </NavLink>

                    </Accordion.Body>

                </Accordion.Item>*/}


                {/* ======================================
                    REPORTS
                ======================================= 

                <Accordion.Item eventKey="6">

                    <Accordion.Header>

                        <div className="accordion-title">

                            <FileTextFill />

                            {
                                !collapsed &&

                                <span>
                                    Reports
                                </span>
                            }

                        </div>

                    </Accordion.Header>


                    <Accordion.Body>

                        <NavLink
                            to="/production-report"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Production Report

                        </NavLink>


                        <NavLink
                            to="/quality-report"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Quality Report

                        </NavLink>


                        <NavLink
                            to="/maintenance-report"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Maintenance Report

                        </NavLink>


                        <NavLink
                            to="/master-report"
                            className="submenu-link"
                        >

                            <span className="submenu-line"></span>

                            Master Data Report

                        </NavLink>

                    </Accordion.Body>

                </Accordion.Item> */}

            </Accordion>

        </div>
    );
}


export default Sidebar;