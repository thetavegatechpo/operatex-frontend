// src/components/layout/Navbar.jsx

import React, { useContext } from "react";

import {
    Navbar,
    Container,
    Button
} from "react-bootstrap";

import {
    BoxArrowRight
} from "react-bootstrap-icons";

import { useNavigate } from "react-router-dom";

import { AuthContext } from "../../context/AuthContext";
import api from "../../services/api";

import logo from "../../assets/images/logo.png";

import "./Navbar.css";

function TopNavbar() {

    const navigate = useNavigate();

    const { signOut } = useContext(AuthContext);

    const handleLogout = async () => {

    try {

        await api.post("/auth/logout");

    } catch (err) {

        console.error("Logout API failed:", err);

    } finally {

        signOut();

        navigate("/login");

    }

};
    return (

        <Navbar
            expand="lg"
            className="operatex-navbar"
        >

            <Container fluid>

                <div className="navbar-left">

                    <img
                        src={logo}
                        alt="OperateX"
                        className="navbar-logo"
                    />

                    <div>

                        <div className="brand-name">

                            <span className="brand-o">
                                O
                            </span>

                            <span className="brand-operate">
                                perate
                            </span>

                            <span className="brand-x">
                                X
                            </span>

                        </div>

                        <div className="brand-subtitle">

                            Industrial Manufacturing Execution Platform

                        </div>

                    </div>

                </div>

                <div className="navbar-center">

                    Manufacturing Monitoring System

                </div>

                <div className="navbar-right">

                    <Button

                        variant="danger"

                        className="logout-btn"

                        onClick={handleLogout}

                    >

                        <BoxArrowRight
                            className="me-2"
                        />

                        Logout

                    </Button>

                </div>

            </Container>

        </Navbar>

    );

}

export default TopNavbar;