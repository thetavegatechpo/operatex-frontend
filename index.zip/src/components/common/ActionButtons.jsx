import React from "react";

import {
    Button
} from "react-bootstrap";

import {
    PencilSquare,
    Trash,
    PlayFill,
    ClockHistory,
    FileText,
    Download
} from "react-bootstrap-icons";

function ActionButtons({

    showEdit = true,
    showDelete = true,
    showExecute = false,
    showRuntime = false,
    showReport = false,
    showExport = false,

    onEdit,
    onDelete,
    onExecute,
    onRuntime,
    onReport,
    onExport

}) {

    return (

        <>

            {
                showEdit &&

                <Button
                    size="sm"
                    variant="outline-primary"
                    className="me-2"
                    onClick={onEdit}
                >
                    <PencilSquare />
                </Button>
            }

            {
                showDelete &&(

                <Button
                    size="sm"
                    variant="outline-danger"
                    className="me-2"
                    onClick={onDelete}
                >
                    <Trash />
                </Button>
           ) }

            {
                showExecute &&

                <Button
                    size="sm"
                    variant="outline-success"
                    className="me-2"
                    onClick={onExecute}
                >
                    <PlayFill />
                </Button>
            }

            {
                showRuntime &&

                <Button
                    size="sm"
                    variant="outline-warning"
                    className="me-2"
                    onClick={onRuntime}
                >
                    <ClockHistory />
                </Button>
            }

            {
                showReport &&

                <Button
                    size="sm"
                    variant="outline-info"
                    className="me-2"
                    onClick={onReport}
                >
                    <FileText />
                </Button>
            }

            {
                showExport &&

                <Button
                    size="sm"
                    variant="outline-dark"
                    onClick={onExport}
                >
                    <Download />
                </Button>
            }

        </>

    );

}

export default ActionButtons;