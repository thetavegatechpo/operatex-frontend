import React from "react";

import {
    Card,
    Row,
    Col
} from "react-bootstrap";

function PageHeader({

    title,

    subtitle,

    children

}) {

    return (

        <Card className="shadow-sm border-0 mb-4">

            <Card.Body>

                <Row className="align-items-center">

                    <Col>

                        <h2 className="fw-bold mb-1">

                            {title}

                        </h2>

                        <div className="text-muted">

                            {subtitle}

                        </div>

                    </Col>

                    <Col
                        xs="auto"
                        className="d-flex gap-2"
                    >

                        {children}

                    </Col>

                </Row>

            </Card.Body>

        </Card>

    );

}

export default PageHeader;