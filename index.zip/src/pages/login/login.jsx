import React, {
    useState,
    useContext
} from "react";

import {
    Container,
    Row,
    Col,
    Card,
    Form,
    Button,
    Spinner,
    InputGroup,
    Alert
} from "react-bootstrap";

import {
    Eye,
    EyeSlash,
    Person,
    Lock
} from "react-bootstrap-icons";

import {
    useNavigate
} from "react-router-dom";

import api from "../../services/api";
import { AuthContext } from "../../context/AuthContext";
import logo from "../../assets/images/logo.png";
import "./login.css";

function Login() {

    const navigate = useNavigate();

    const { login } = useContext(AuthContext);

    const [username, setUsername] = useState("");

    const [password, setPassword] = useState("");

    const [showPassword, setShowPassword] = useState(false);

    const [remember, setRemember] = useState(true);

    const [loading, setLoading] = useState(false);

    const [error, setError] = useState("");

    const handleLogin = async (e) => {

        e.preventDefault();

        setLoading(true);

        setError("");

        try {

            const response = await api.post(

                "/auth/login",

                {

                    username,

                    password

                }

            );

            login(

                response.data.data.token,

                response.data.data.user

            );

            navigate("/dashboard");

        }

        catch (err) {

            setError(

                err.response?.data?.message ||

                "Invalid username or password."

            );

        }

        finally {

            setLoading(false);

        }

    };

    return (

        <Container
            fluid
            className="login-page"
        >

            <div className="login-overlay"></div>

            <Row className="justify-content-center align-items-center min-vh-100">

                <Col
                    lg={5}
                    md={8}
                    sm={11}
                >

                    <Card className="login-card">

                        <Card.Body>

                            <div className="text-center mb-4">

                                <img

                                    src={logo}

                                    alt="OperateX"

                                    className="login-logo"

                                />

                                <h2 className="mt-3 fw-bold">

                                    Welcome Back!

                                </h2>

                                <p className="text-muted">

                                    Sign in to continue to your dashboard

                                </p>

                            </div>

                            {

                                error &&

                                <Alert variant="danger">

                                    {error}

                                </Alert>

                            }

                            <Form onSubmit={handleLogin}>

                                <Form.Group className="mb-3">

                                    <Form.Label>

                                        Username

                                    </Form.Label>

                                    <InputGroup>

                                        <InputGroup.Text>

                                            <Person />

                                        </InputGroup.Text>

                                        <Form.Control

                                            type="text"

                                            placeholder="Enter Username"

                                            value={username}

                                            onChange={(e) =>

                                                setUsername(

                                                    e.target.value

                                                )

                                            }

                                            required

                                        />

                                    </InputGroup>

                                </Form.Group>

                                <Form.Group className="mb-3">

                                    <Form.Label>

                                        Password

                                    </Form.Label>

                                    <InputGroup>

                                        <InputGroup.Text>

                                            <Lock />

                                        </InputGroup.Text>

                                        <Form.Control

                                            type={

                                                showPassword

                                                    ? "text"

                                                    : "password"

                                            }

                                            placeholder="Enter Password"

                                            value={password}

                                            onChange={(e) =>

                                                setPassword(

                                                    e.target.value

                                                )

                                            }

                                            required

                                        />

                                        <Button

                                            variant="light"

                                            onClick={() =>

                                                setShowPassword(

                                                    !showPassword

                                                )

                                            }

                                        >

                                            {

                                                showPassword

                                                    ?

                                                    <EyeSlash />

                                                    :

                                                    <Eye />

                                            }

                                        </Button>

                                    </InputGroup>

                                </Form.Group>

                                <div className="d-flex justify-content-between align-items-center mb-4">

                                    <Form.Check

                                        type="checkbox"

                                        label="Remember Me"

                                        checked={remember}

                                        onChange={() =>

                                            setRemember(

                                                !remember

                                            )

                                        }

                                    />

                                    <Button

                                        variant="link"

                                        className="forgot-btn"

                                    >

                                        Forgot Password?

                                    </Button>

                                </div>

                                <Button

                                    type="submit"

                                    className="login-btn w-100"

                                    disabled={loading}

                                >

                                    {

                                        loading

                                            ?

                                            <>
                                                <Spinner

                                                    animation="border"

                                                    size="sm"

                                                    className="me-2"

                                                />

                                                Signing In...
                                            </>

                                            :

                                            "Sign In"

                                    }

                                </Button>

                                <div className="divider my-4">

                                    <span>

                                        OR

                                    </span>

                                </div>

                                <Row>

                                    <Col>

                                        <Button

                                            variant="outline-secondary"

                                            className="social-btn w-100"

                                        >

                                            SSO

                                        </Button>

                                    </Col>

                                    <Col>

                                        <Button

                                            variant="outline-secondary"

                                            className="social-btn w-100"

                                        >

                                            Microsoft

                                        </Button>

                                    </Col>

                                    <Col>

                                        <Button

                                            variant="outline-secondary"

                                            className="social-btn w-100"

                                        >

                                            Google

                                        </Button>

                                    </Col>

                                </Row>

 

</Form>

</Card.Body>

</Card>

</Col>

</Row>

</Container>

);

}

export default Login;