// src/services/api.js

import axios from "axios";

const api = axios.create({

    baseURL: import.meta.env.VITE_API_BASE_URL,

    timeout: 15000,

    headers: {

        "Content-Type": "application/json"

    }

});

// ==========================================
// REQUEST INTERCEPTOR
// ==========================================

api.interceptors.request.use(

    (config) => {

        const token =
            localStorage.getItem("operatex_token");

        if (token) {

            config.headers.Authorization =
                `Bearer ${token}`;

        }

        return config;

    },

    (error) => {

        return Promise.reject(error);

    }

);

// ==========================================
// RESPONSE INTERCEPTOR
// ==========================================

api.interceptors.response.use(

    (response) => response,

    (error) => {

        if (

            error.response &&

            error.response.status === 401

        ) {

            localStorage.removeItem("operatex_token");

            localStorage.removeItem("operatex_user");

            window.location.href = "/login";

        }

        return Promise.reject(error);

    }

);

export default api;