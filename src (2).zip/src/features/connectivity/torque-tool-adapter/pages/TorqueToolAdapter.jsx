import React from "react";
import ConnectivityAdapter from "../../_shared/pages/ConnectivityAdapter.jsx";
import definition from "../api/definition.js";
export default function TorqueToolAdapter(){return <ConnectivityAdapter definition={definition}/>;}
