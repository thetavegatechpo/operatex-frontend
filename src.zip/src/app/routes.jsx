import React from "react";

import {
    Routes,
    Route,
    Navigate
} from "react-router-dom";



import Login from "../features/auth/pages/login.jsx";

import Layout from "../shared/layout/Layout.jsx";

import Dashboard from "../features/dashboard/pages/Dashboard.jsx";


/* =====================================
   ENTERPRISE SETUP
===================================== */

import CompanyMaster from "../features/enterprise-setup/company-master/pages/CompanyMaster.jsx";
import PlantShopMaster from "../features/enterprise-setup/plant-shop-master/pages/PlantShopMaster.jsx";
import LineMaster from "../features/enterprise-setup/line-master/pages/LineMaster.jsx";
import ShiftCalendar from "../features/enterprise-setup/shift-calendar/pages/ShiftCalendar.jsx";
import ModuleEnablement from "../features/enterprise-setup/module-enablement/pages/ModuleEnablement.jsx";
import UserRolePermission from "../features/enterprise-setup/user-role-permission/pages/UserRolePermission.jsx";
import StationMaster from "../features/master-data/station-master/pages/StationMaster.jsx";


/* =====================================
   MASTER DATA
===================================== */

import MachineMaster from "../features/master-data/machine-master/pages/MachineMaster.jsx";
import DeviceMaster from "../features/master-data/device-master/pages/DeviceMaster.jsx";
import SignalMapping from "../features/master-data/signal-mapping/pages/SignalMapping.jsx";
import PartMaster from "../features/master-data/part-master/pages/PartMaster.jsx";
import ProcessMaster from "../features/master-data/process-master/pages/ProcessMaster.jsx";
import RouteMaster from "../features/master-data/route-station-master/pages/RouteMaster.jsx";
import ToolMaster from "../features/master-data/tool-master/pages/ToolMaster.jsx";
import GaugeInstrumentMaster from "../features/master-data/gauge-instrument-master/pages/GaugeInstrumentMaster.jsx";
import DocumentMaster from "../features/master-data/document-sop-master/pages/DocumentMaster.jsx";
import SkillMatrix from "../features/master-data/skill-matrix/pages/SkillMatrix.jsx";


/* =====================================
   PLANNING
===================================== */

import ProductionOrder from "../features/planning/production-order/pages/ProductionOrder.jsx";

import Productionplan from "../features/planning/production-plan/pages/ProductionPlan.jsx";

import ShiftPlan from "../features/planning/shift-plan/pages/ShiftPlan.jsx";
import SchedulingRules from "../features/planning/scheduling-rules/pages/SchedulingRules.jsx";
import MaterialBatchHeatCode
  from "../features/planning/material-batch-heat-code/pages/MaterialBatchHeatCode.jsx";
  import ChangeoverSetupPlan
    from "../features/planning/changeover-setup-plan/pages/ChangeoverSetupPlan.jsx";
import OperatorWorkstation
  from "../features/production-execution/operator-workstation/pages/OperatorWorkstation.jsx";

import ProductionCount
    from "../features/production-execution/production-count/pages/ProductionCount.jsx";

import CycleTimeTracking
    from "../features/production-execution/cycle-time-tracking/pages/CycleTimeTracking.jsx"; 
    
import MachineStatus from "../features/production-execution/machine-status/pages/MachineStatus.jsx"; 

import LineIndexingUnitMovement from "../features/production-execution/line-indexing-unit-movement/pages/LineIndexingUnitMovement.jsx";

import ReworkRejectBypass
  from "../features/production-execution/rework-reject-bypass/pages/ReworkRejectBypass.jsx";

  import DowntimeDetection
    from "../features/oee-loss/downtime-detection/pages/DowntimeDetectionPage.jsx";
import Availability from "../features/oee-loss/availability/pages/Availability.jsx";
import Performance from "../features/oee-loss/performance/pages/Performance.jsx";
import Quality from "../features/oee-loss/quality/pages/Quality.jsx";
import OEE from "../features/oee-loss/oee-formula/pages/OEE.jsx";
import BreakdownManagement from "../features/oee-loss/breakdown-management/pages/BreakdownManagement.jsx";
import MttrMtbf from "../features/oee-loss/mttr-mtbf/pages/MttrMtbf.jsx";
import LossTree from '../features/oee-loss/loss-tree/pages/LossTree.jsx';
/* =====================================
   PROTECTED ROUTE
===================================== */

import ProtectedRoute from '../features/auth/components/ProtectedRoute.jsx';

/* =====================================
   APP
===================================== */

function AppRoutes() {

    return (



            <Routes>

                {/* =====================================
                    LOGIN
                ====================================== */}

                <Route
                    path="/login"
                    element={<Login />}
                />


                {/* =====================================
                    MAIN LAYOUT
                ====================================== */}

                <Route
                    path="/"
                    element={
                        <ProtectedRoute>
                            <Layout />
                        </ProtectedRoute>
                    }
                >

                    {/* DEFAULT */}

                    <Route
                        index
                        element={
                            <Navigate
                                to="/dashboard"
                                replace
                            />
                        }
                    />


                    {/* =====================================
                        DASHBOARD
                    ====================================== */}

                    <Route
                        path="dashboard"
                        element={<Dashboard />}
                    />


                    {/* =====================================
                        ENTERPRISE SETUP
                    ====================================== */}

                    <Route
                        path="company-master"
                        element={<CompanyMaster />}
                    />

                    <Route
                        path="plant-shop-master"
                        element={<PlantShopMaster />}
                    />

                    <Route
                        path="line-master"
                        element={<LineMaster />}
                    />

                    <Route
                        path="shift-calendar"
                        element={<ShiftCalendar />}
                    />

                    <Route
                        path="user-role-permission"
                        element={<UserRolePermission />}
                    />

                    <Route
                        path="module-enablement"
                        element={<ModuleEnablement />}
                    />

                    <Route
                        path="station-master"
                        element={<StationMaster />}
                    />


                    {/* =====================================
                        MASTER DATA
                    ====================================== */}

                    <Route
                        path="machine-master"
                        element={<MachineMaster />}
                    />

                    <Route
                        path="device-master"
                        element={<DeviceMaster />}
                    />

                    <Route
                        path="signal-mapping"
                        element={<SignalMapping />}
                    />

                    <Route
                        path="part-master"
                        element={<PartMaster />}
                    />

                    <Route
                        path="process-master"
                        element={<ProcessMaster />}
                    />

                    <Route
                        path="route-master"
                        element={<RouteMaster />}
                    />

                    <Route
                        path="tool-master"
                        element={<ToolMaster />}
                    />

                    <Route
                        path="gauge-instrument-master"
                        element={<GaugeInstrumentMaster />}
                    />

                    <Route
                        path="document-master"
                        element={<DocumentMaster />}
                    />

                    <Route
                        path="skill-matrix"
                        element={<SkillMatrix />}
                    />


                    {/* =====================================
                        PLANNING
                    ====================================== */}

                    <Route
                        path="production-order"
                        element={<ProductionOrder />}
                    />


                      <Route
                        path="production-Plan"
                        element={<Productionplan />}
                    />
<Route
    path="/shift-plan"
    element={<ShiftPlan />}
/>

<Route
  path="/scheduling-rules"
  element={<SchedulingRules />}
/>
<Route
  path="/material-batch-heat-code"
  element={<MaterialBatchHeatCode />}
/>

<Route
    path="/changeover-setup-plan"
    element={<ChangeoverSetupPlan />}
/>


<Route
  path="/operator-workstation"
  element={<OperatorWorkstation />}
/>

<Route
    path="/production-count"
    element={<ProductionCount />}
/>

<Route
    path="/cycle-time-tracking"
    element={<CycleTimeTracking />}
/>

<Route
    path="/machine-status"
    element={<MachineStatus />}
/>

<Route
    path="/line-indexing-unit-movement"
    element={<LineIndexingUnitMovement />}

/>  <Route
  path="/rework-reject-bypass"
  element={<ReworkRejectBypass />}
/> 
<Route
    path="/downtime-detection"
    element={<DowntimeDetection />}
/>
<Route path="/availability" element={<Availability />} />

<Route
    path="performance"
    element={<Performance />}
/>

<Route path="/oee" element={<OEE />} />


<Route path="/quality" element={<Quality />} />

<Route path="/breakdown-management" element={<BreakdownManagement />} />  
<Route path="/mttr-mtbf" element={<MttrMtbf />}/>  
<Route path="/loss-tree" element={<LossTree />} />

                </Route> 

            


                {/* =====================================
                    404
                ====================================== */}

                <Route
                    path="*"
                    element={
                        <Navigate
                            to="/login"
                            replace
                        />
                    }
                />

            </Routes>


    );
}

export default AppRoutes;