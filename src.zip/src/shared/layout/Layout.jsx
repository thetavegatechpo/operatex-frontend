// src/components/layout/Layout.jsx

import React from "react";
import { Outlet } from "react-router-dom";

import Navbar from "./Navbar.jsx";
import Sidebar from "./Sidebar.jsx";

import "./Layout.css";

function Layout() {

    return (

        <div className="app-layout">

            {/* Full Width Navbar */}

            <Navbar />

            {/* Sidebar + Content */}

            <div className="app-body">

                <Sidebar />

                <main className="app-content">

                    <Outlet />

                </main>

            </div>

        </div>

    );

}

export default Layout;