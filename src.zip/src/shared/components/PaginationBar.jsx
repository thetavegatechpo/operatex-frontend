import React from "react";

import {

    Row,
    Col,
    Pagination,
    Form

} from "react-bootstrap";

function PaginationBar({

    currentPage = 1,

    totalPages = 1,

    pageSize = 10,

    totalRecords = 0,

    onPageChange,

    onPageSizeChange

}) {

    const pages = [];

    for (

        let i = 1;

        i <= totalPages;

        i++

    ) {

        pages.push(

            <Pagination.Item

                key={i}

                active={i === currentPage}

                onClick={() =>

                    onPageChange(i)

                }

            >

                {i}

            </Pagination.Item>

        );

    }

    return (

        <Row

            className="align-items-center mt-3"

        >

            <Col md={4}>

                <strong>

                    Total Records :

                    {" "}

                    {totalRecords}

                </strong>

            </Col>

            <Col

                md={4}

                className="text-center"

            >

                <Pagination

                    className="justify-content-center mb-0"

                >

                    <Pagination.First

                        onClick={() =>

                            onPageChange(1)

                        }

                        disabled={currentPage===1}

                    />

                    <Pagination.Prev

                        onClick={()=>

                            onPageChange(

                                currentPage-1

                            )

                        }

                        disabled={currentPage===1}

                    />

                    {pages}

                    <Pagination.Next

                        onClick={()=>

                            onPageChange(

                                currentPage+1

                            )

                        }

                        disabled={

                            currentPage===totalPages

                        }

                    />

                    <Pagination.Last

                        onClick={()=>

                            onPageChange(

                                totalPages

                            )

                        }

                        disabled={

                            currentPage===totalPages

                        }

                    />

                </Pagination>

            </Col>

            <Col

                md={4}

                className="text-end"

            >

                <Form.Select

                    style={{

                        width:130,

                        display:"inline-block"

                    }}

                    value={pageSize}

                    onChange={(e)=>

                        onPageSizeChange(

                            Number(

                                e.target.value

                            )

                        )

                    }

                >

                    <option value={10}>10</option>

                    <option value={20}>20</option>

                    <option value={50}>50</option>

                    <option value={100}>100</option>

                </Form.Select>

            </Col>

        </Row>

    );

}

export default PaginationBar;