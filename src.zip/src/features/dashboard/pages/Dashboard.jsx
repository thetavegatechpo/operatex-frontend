import React from "react";

import "./Dashboard.css";

function Dashboard(){

    return(

        <div className="dashboard-page">

            <h2>Dashboard</h2>

            <p>

                Welcome to OperateX MES

            </p>

        </div>

    );

}

export default Dashboard;